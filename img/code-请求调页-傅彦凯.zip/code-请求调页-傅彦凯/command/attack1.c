#include "stdio.h"

int main(int argc, char * argv[])
{
    int i = 1;
    int a[10] = {1,2,3,4,5,6,7,8,9,10};
    for(i; i < argc; i++)
    {
	    printf(argv[i]);
        printf(" ");
    }
	return 0;
}